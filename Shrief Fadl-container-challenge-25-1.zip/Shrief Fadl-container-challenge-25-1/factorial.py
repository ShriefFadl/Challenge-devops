import random
def fact(n):  
    return 1 if (n==1 or n==0) else n * fact(n - 1);  
  
num =random.randint(1,10)
print("Factorial of",num,"is",fact(num))